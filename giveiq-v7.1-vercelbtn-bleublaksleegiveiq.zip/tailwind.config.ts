import type { Config } from "tailwindcss";
const config: Config = {
  darkMode: "class",
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand:{50:"#eef6ff",100:"#d9ebff",200:"#b5d7ff",300:"#88bfff",400:"#519cff",500:"#1f7aff",600:"#155fd6",700:"#104aa8",800:"#0b366f",900:"#09264d"},
        accent:{500:"#10b981",600:"#0ea370"}
      },
      boxShadow:{soft:"0 8px 24px rgba(0,0,0,0.08)"}
    }
  },
  plugins: []
};
export default config;

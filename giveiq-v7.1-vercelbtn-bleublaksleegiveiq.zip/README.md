
## One‑click Deploy

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/bleublaksleegiveiq/giveiq&project-name=giveiq&repository-name=giveiq&env=ADMIN_PASSWORD,NEWS_API_ENDPOINT,NEWS_API_KEY&envDescription=Set%20ADMIN_PASSWORD%20and%20(optional)%20NewsAPI%20vars%20in%20Vercel.&demo-title=GiveIQ&demo-description=Charitable%20giving%20toolkit)
> Replace `bleublaksleegiveiq` in the URL above after you push this repo to your own GitHub account.

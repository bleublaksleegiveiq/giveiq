export type Sponsor = {
  name: string; url: string; minToOpen?: string; minGrant?: string;
  adminFeeSummary?: string; advisorProgramNote?: string; specialInfo?: string; lastVerified?: string;
};

export const sponsors: Sponsor[] = [
  { name: "Fidelity Charitable", url: "https://www.fidelitycharitable.org/", minToOpen: "None (Core)", minGrant: "$50", adminFeeSummary:"Tiered; see site", advisorProgramNote:"Advisor-managed at higher balances", specialInfo:"Sponsor issues your receipt", lastVerified:"2025-08-10" },
  { name: "Schwab Charitable", url: "https://www.schwabcharitable.org/", minToOpen: "None (Core)", minGrant: "$50", adminFeeSummary:"Admin 0.60% (min $100) core; tiered rebates", advisorProgramNote:"Professionally managed $100k+ (typical)", specialInfo:"", lastVerified:"2025-08-10" },
  { name: "Vanguard Charitable", url: "https://www.vanguardcharitable.org/", minToOpen: "$25,000", minGrant: "$500", adminFeeSummary:"Low all‑in fee model", advisorProgramNote:"Advisor support for larger funds", specialInfo:"", lastVerified:"2025-08-10" },
  { name: "National Philanthropic Trust (NPT)", url: "https://www.nptrust.org/", minToOpen: "$10,000", minGrant: "$250", adminFeeSummary:"Tiered admin; see program guide", advisorProgramNote:"Advisor-led investing available", specialInfo:"Publishes annual DAF Report", lastVerified:"2025-08-10" },
  { name: "American Endowment Foundation (AEF)", url: "https://www.aefonline.org/", minToOpen: "See site", minGrant: "See site", adminFeeSummary: "See site", advisorProgramNote: "Advisor-centric model", specialInfo: "", lastVerified: "2025-08-10" },
  { name: "Renaissance Charitable Foundation", url: "https://www.reninc.com/charitable-solutions/donor-advised-funds/", minToOpen: "See site", minGrant: "See site", adminFeeSummary: "See site", advisorProgramNote: "Advisor-managed options", specialInfo: "", lastVerified: "2025-08-10" },
  { name: "BNY Mellon Charitable Gift Fund", url: "https://www.bnymelloncharitablegiftfund.org/", minToOpen: "See site", minGrant: "See site", adminFeeSummary: "See site", advisorProgramNote: "Available via advisors", specialInfo: "", lastVerified: "2025-08-10" },
  { name: "Goldman Sachs Philanthropy Fund", url: "https://www.goldmansachs.com/what-we-do/wealth-management/private-wealth-management/philanthropy/philanthropy-fund/", minToOpen: "See site", minGrant: "See site", adminFeeSummary: "See site", advisorProgramNote: "Private wealth/advisor platform", specialInfo: "", lastVerified: "2025-08-10" },
  { name: "Silicon Valley Community Foundation (DAF)", url: "https://www.siliconvalleycf.org/donors/give/donor-advised-funds", minToOpen: "See site", minGrant: "See site", adminFeeSummary: "Community foundation schedule", advisorProgramNote: "Varies by program", specialInfo: "Regional/community focus", lastVerified: "2025-08-10" },
  { name: "Greater Kansas City Community Foundation (GKCCF)", url: "https://www.growyourgiving.org/", minToOpen: "See site", minGrant: "See site", adminFeeSummary: "Community foundation schedule", advisorProgramNote: "Advisor-managed options", specialInfo: "One of the largest community foundations", lastVerified: "2025-08-10" }
];

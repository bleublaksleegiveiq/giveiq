import Card from "@/components/Card"; import Disclaimer from "@/components/Disclaimer"; import PrintToPDF from "@/components/PrintToPDF";
export default function QCDPage(){
  return (<div className='space-y-6'>
    <div className='flex items-center justify-between gap-4'><h1 className='text-3xl font-bold'>Qualified Charitable Distributions (QCDs) — IRA</h1><div className='md:hidden'><PrintToPDF/></div></div>
    <p className='lead'>What a QCD is, eligibility, do’s & don’ts, and how it affects taxes.</p>
    <Card title='Key Rules'>
      <ul className='list-disc pl-6 space-y-1'><li>You must be at least 70½ on the date of transfer.</li><li>Funds go directly from your IRA custodian to an eligible public charity.</li><li>Private foundations, DAFs, and supporting organizations are generally ineligible.</li><li>QCDs can count toward RMDs when applicable.</li></ul>
    </Card>
    <Card title='Do’s & Don’ts'><ul className='list-disc pl-6 space-y-1'><li>Coordinate with your custodian for a direct transfer.</li><li>Get an acknowledgment from the charity stating no goods/services were received.</li><li>Don’t route the funds to yourself first.</li></ul></Card>
    <Card title='Tax Notes'><p>QCDs are typically excluded from taxable income; you don’t also claim an itemized deduction for the same dollars. Keep acknowledgments and confirm current-year rules with your advisor.</p></Card>
    <Disclaimer/>
  </div>);
}

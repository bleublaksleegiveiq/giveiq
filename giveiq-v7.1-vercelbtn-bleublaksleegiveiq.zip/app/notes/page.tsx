'use client';
import Card from "@/components/Card"; import Disclaimer from "@/components/Disclaimer"; import PrintToPDF from "@/components/PrintToPDF"; import { useEffect, useState } from "react";
type Note={id:string;date:string;text:string};
function todayISO(){const d=new Date(); const z=(n:number)=>String(n).padStart(2,'0'); return `${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())}`;}
export default function NotesPage(){
  const [items,setItems]=useState<Note[]>([]);
  const [date,setDate]=useState(todayISO());
  const [text,setText]=useState("");
  useEffect(()=>{const s=localStorage.getItem('giveiq_notes'); if(s) try{setItems(JSON.parse(s))}catch{}},[]);
  function persist(next:Note[]){setItems(next); localStorage.setItem('giveiq_notes', JSON.stringify(next));}
  function add(){if(!text.trim())return; persist([{id:crypto.randomUUID(),date,text:text.trim()},...items]); setText("");}
  function remove(id:string){persist(items.filter(n=>n.id!==id));}
  return (<div className='space-y-6'>
    <div className='flex items-center justify-between gap-4'><h1 className='text-3xl font-bold'>Notes</h1><div className='md:hidden'><PrintToPDF/></div></div>
    <p className='lead'>Capture ideas, pledges to revisit, and questions for your advisor—each note is timestamped.</p>
    <Card title='New Note'>
      <div className='grid md:grid-cols-3 gap-3'>
        <label className='flex flex-col gap-1'><span>Date</span><input type='date' value={date} onChange={e=>setDate(e.target.value)} className='border rounded p-2'/></label>
        <label className='md:col-span-2 flex flex-col gap-1'><span>Note</span><textarea value={text} onChange={e=>setText(e.target.value)} className='border rounded p-2 h-24'/></label>
      </div>
      <div className='mt-3'><button onClick={add} className='px-4 py-2 rounded bg-brand-600 text-white hover:bg-brand-700'>Add</button></div>
    </Card>
    <Card title='All Notes'>
      {items.length===0 ? <p className='text-sm text-gray-500'>No notes yet.</p> :
        <ul className='space-y-2'>{items.map(n=>(<li key={n.id} className='border rounded p-2 flex items-start justify-between gap-3 text-sm'><div><div className='text-gray-500'>{n.date}</div><div>{n.text}</div></div><button onClick={()=>remove(n.id)} className='underline text-red-600'>Delete</button></li>))}</ul>}
    </Card>
    <Disclaimer/>
  </div>);
}

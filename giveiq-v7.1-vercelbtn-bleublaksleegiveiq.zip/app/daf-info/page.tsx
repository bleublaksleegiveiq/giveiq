import Card from "@/components/Card"; import Disclaimer from "@/components/Disclaimer"; import PrintToPDF from "@/components/PrintToPDF"; import { sponsors } from "@/lib/sponsors";
export default function DAFInfoPage(){
  return (<div className='space-y-6'>
    <div className='flex items-center justify-between gap-4'><h1 className='text-3xl font-bold'>Donor‑Advised Funds (DAFs) — Guide</h1><div className='md:hidden'><PrintToPDF/></div></div>
    <p className='lead'>What a DAF is, how tax receipts work, investing options, advisor participation, and leading sponsors.</p>
    <Card title='What is a DAF?'><p>A Donor‑Advised Fund is a charitable account at a sponsoring charity. You contribute assets, receive a tax acknowledgment from the sponsor, and recommend grants to nonprofits over time.</p></Card>
    <Card title='Tax Deduction & Receipts'>
      <ul className='list-disc pl-6 space-y-1'><li>Deduction generally occurs in the year you contribute (itemizers, AGI limits apply).</li><li>The DAF sponsor issues your donation receipt. Grantee charities typically send thank‑you notes (not receipts) when the DAF grants.</li></ul>
    </Card>
    <Card title='Investing & Advisors'><p>Most sponsors offer investment pools and/or advisor‑managed options at higher balances. Confirm minimums, fees, and menus with the sponsor.</p></Card>
    <Card title='Top Sponsors (snapshot)'>
      <div className='overflow-x-auto'><table className='min-w-full text-sm'>
        <thead className='bg-gray-50'><tr><th className='text-left p-2'>Sponsor</th><th className='text-left p-2'>Min to Open</th><th className='text-left p-2'>Min Grant</th><th className='text-left p-2'>Admin Fee</th><th className='text-left p-2'>Advisor Program</th><th className='text-left p-2'>Link</th><th className='text-left p-2'>Last Verified</th></tr></thead>
        <tbody>{sponsors.map(s=>(<tr key={s.name} className='border-b align-top'><td className='p-2 font-medium'>{s.name}</td><td className='p-2'>{s.minToOpen||"—"}</td><td className='p-2'>{s.minGrant||"—"}</td><td className='p-2'>{s.adminFeeSummary||"—"}</td><td className='p-2'>{s.advisorProgramNote||"—"}</td><td className='p-2'><a className='underline text-accent-500' href={s.url} target='_blank'>Visit</a></td><td className='p-2 whitespace-nowrap'>{s.lastVerified||"—"}</td></tr>))}</tbody>
      </table></div>
      <p className='text-xs text-gray-500 mt-2'>Always confirm current fees and policies on each sponsor’s site.</p>
    </Card>
    <Card title='What DAFs can’t do (generally)'><ul className='list-disc pl-6 space-y-1'><li>No tuition, dues, or membership benefits.</li><li>No tickets or goods/services in return.</li><li>Restrictions vary by sponsor; check ahead.</li></ul></Card>
    <Disclaimer/>
  </div>);
}

import Card from "@/components/Card"; import Disclaimer from "@/components/Disclaimer"; import PrintToPDF from "@/components/PrintToPDF";
export default function RealEstatePage(){
  return (<div className='space-y-6'>
    <div className='flex items-center justify-between gap-4'><h1 className='text-3xl font-bold'>Real Estate Gifts</h1><div className='md:hidden'><PrintToPDF/></div></div>
    <p className='lead'>Due diligence and coordination tips when donating real property.</p>
    <Card title='Checklist'>
      <ul className='list-disc pl-6 space-y-1 text-gray-700 dark:text-gray-300'>
        <li>Confirm title, liens, encumbrances, HOA rules, and environmental status.</li>
        <li>Obtain a qualified appraisal when required.</li>
        <li>Coordinate with the receiving charity’s real‑assets team and your advisor.</li>
      </ul>
    </Card>
    <Disclaimer/>
  </div>);
}

import Card from "@/components/Card"; import Disclaimer from "@/components/Disclaimer"; import PrintToPDF from "@/components/PrintToPDF";
export default function CryptoPage(){
  return (<div className='space-y-6'>
    <div className='flex items-center justify-between gap-4'><h1 className='text-3xl font-bold'>Donate Cryptocurrency</h1><div className='md:hidden'><PrintToPDF/></div></div>
    <p className='lead'>How crypto gifts are treated for tax purposes, and where to donate.</p>
    <Card title='How to Give'>
      <ul className='list-disc pl-6 text-gray-700 dark:text-gray-300 space-y-1'>
        <li>Use platforms like The Giving Block to donate major coins.</li>
        <li>For appreciated crypto held &gt; 1 year, donors may be eligible for a deduction up to FMV (AGI limits apply).</li>
        <li>Donations are typically irrevocable; confirm wallet addresses and charity eligibility.</li>
      </ul>
    </Card>
    <Card title='Tax Notes'>
      <p className='text-gray-700 dark:text-gray-300'>Document acquisition date and cost basis. A qualified appraisal may be required above certain thresholds. Confirm with your advisor.</p>
    </Card>
    <Disclaimer/>
  </div>);
}

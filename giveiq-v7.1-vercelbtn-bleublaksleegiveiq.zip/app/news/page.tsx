'use client';
import Card from "@/components/Card"; import Disclaimer from "@/components/Disclaimer"; import PrintToPDF from "@/components/PrintToPDF"; import { useEffect, useState } from "react";
type Article={title?:string;url?:string;description?:string;source?:any;publishedAt?:string};
export default function NewsPage(){
  const [q,setQ]=useState("charitable giving tax OR donor-advised fund OR QCD OR CGA OR philanthropy policy");
  const [items,setItems]=useState<Article[]>([]);
  const [configured,setConfigured]=useState(false);
  const [loading,setLoading]=useState(false);
  async function load(){
    setLoading(true);
    const res=await fetch(`/api/news?q=${encodeURIComponent(q)}`);
    const d=await res.json();
    setConfigured(!!d.configured);
    setItems(d.results||[]);
    setLoading(false);
  }
  useEffect(()=>{load();},[]);
  return (<div className='space-y-6'>
    <div className='flex items-center justify-between gap-4'><h1 className='text-3xl font-bold'>News & Legislation</h1><div className='md:hidden'><PrintToPDF/></div></div>
    <p className='lead'>Find current articles and policy updates that impact charitable giving.</p>
    <Card title='Search'><div className='flex flex-wrap gap-3'><input value={q} onChange={e=>setQ(e.target.value)} className='border rounded p-2 flex-1 min-w-[240px]'/><button onClick={load} className='px-4 py-2 rounded bg-brand-600 text-white hover:bg-brand-700'>{loading?'Searching…':'Search'}</button></div></Card>
    {!configured && <Card title='Setup'><p className='text-sm text-gray-600'>Add <code>NEWS_API_ENDPOINT</code> and <code>NEWS_API_KEY</code> in your hosting environment. The app auto-detects NewsAPI.org and uses the <code>X-Api-Key</code> header.</p></Card>}
    <Card title='Results'>
      {items.length===0 ? <p className='text-sm text-gray-500'>No results yet.</p> :
        <ul className='space-y-3'>{items.map((a,i)=>(<li key={i} className='border rounded p-3'><a className='font-medium underline' href={a.url} target='_blank' rel='noreferrer'>{a.title||'Untitled'}</a><div className='text-sm text-gray-600'>{a.description}</div>{a.publishedAt && <div className='text-xs text-gray-500 mt-1'>{new Date(a.publishedAt).toLocaleString()}</div>}</li>))}</ul>}
    </Card>
    <Disclaimer/>
  </div>);
}

'use client';
import Card from "@/components/Card"; import Disclaimer from "@/components/Disclaimer"; import PrintToPDF from "@/components/PrintToPDF"; import { useEffect, useState } from "react";
type Receipt={id:string;year:string;name:string;dataUrl:string;createdAt:string};
export default function ReceiptsPage(){
  const [year,setYear]=useState(String(new Date().getFullYear()));
  const [name,setName]=useState("");
  const [items,setItems]=useState<Receipt[]>([]);
  useEffect(()=>{const s=localStorage.getItem('giveiq_receipts'); if(s) try{setItems(JSON.parse(s))}catch{}},[]);
  function persist(next:Receipt[]){setItems(next); localStorage.setItem('giveiq_receipts', JSON.stringify(next));}
  async function onFile(files:FileList|null){
    if(!files||!files.length)return;
    for(const f of Array.from(files)){
      const dataUrl=await fileToDataURL(f);
      const id=crypto.randomUUID();
      const rec:Receipt={id,year,name:name||f.name,dataUrl,createdAt:new Date().toISOString()};
      persist([rec,...items]);
    }
    setName("");
  }
  function remove(id:string){persist(items.filter(i=>i.id!==id));}
  const filtered=items.filter(i=>i.year===year);
  return (<div className='space-y-6'>
    <div className='flex items-center justify-between gap-4'><h1 className='text-3xl font-bold'>Receipt Locker</h1><div className='md:hidden'><PrintToPDF/></div></div>
    <p className='lead'>Capture and organize your charitable receipts by tax year (stored locally on your device).</p>
    <Card title='Add a Receipt'>
      <div className='grid md:grid-cols-3 gap-3'>
        <label className='flex flex-col gap-1'><span>Tax year</span><input value={year} onChange={e=>setYear(e.target.value)} className='border rounded p-2'/></label>
        <label className='flex flex-col gap-1'><span>Label</span><input value={name} onChange={e=>setName(e.target.value)} className='border rounded p-2'/></label>
        <label className='flex flex-col gap-1'><span>Image</span><input type='file' accept='image/*' multiple onChange={e=>onFile(e.target.files)} className='border rounded p-2'/></label>
      </div>
    </Card>
    <Card title={`Receipts for ${year}`}>
      {filtered.length===0 ? <p className='text-sm text-gray-500'>No receipts yet.</p> :
        <div className='grid sm:grid-cols-2 md:grid-cols-3 gap-4'>
          {filtered.map(r=>(<figure key={r.id} className='border rounded p-2'><img src={r.dataUrl} alt={r.name} className='w-full h-48 object-contain bg-gray-50'/><figcaption className='mt-2 text-xs flex items-center justify-between'><span className='truncate'>{r.name}</span><button onClick={()=>remove(r.id)} className='underline text-red-600'>Delete</button></figcaption></figure>))}
        </div>}
    </Card>
    <Disclaimer/>
  </div>);
}
function fileToDataURL(file:File){return new Promise<string>((resolve,reject)=>{const r=new FileReader(); r.onload=()=>resolve(String(r.result)); r.onerror=reject; r.readAsDataURL(file);});}

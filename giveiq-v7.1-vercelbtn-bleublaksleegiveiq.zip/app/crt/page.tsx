import Card from "@/components/Card"; import Disclaimer from "@/components/Disclaimer"; import PrintToPDF from "@/components/PrintToPDF";
export default function CRTPage(){
  return (<div className='space-y-6'>
    <div className='flex items-center justify-between gap-4'><h1 className='text-3xl font-bold'>Charitable Remainder Trusts (CRTs)</h1><div className='md:hidden'><PrintToPDF/></div></div>
    <p className='lead'>Compare CRATs, CRUTs, NIMCRUTs, and Flip‑CRUTs—key tests and planning notes.</p>
    <Card title='Types'>
      <ul className='list-disc pl-6 space-y-1 text-gray-700 dark:text-gray-300'>
        <li><strong>CRAT:</strong> fixed dollar payout (5–50%); 10% remainder test.</li>
        <li><strong>CRUT:</strong> fixed percentage of annual value; variants include NIMCRUT and Flip‑CRUT.</li>
        <li>Remainder goes to charity; payouts taxed under tier rules.</li>
      </ul>
    </Card>
    <Card title='Considerations'>
      <ul className='list-disc pl-6 space-y-1 text-gray-700 dark:text-gray-300'>
        <li>Funding with appreciated assets can spread/shift gains.</li>
        <li>Setup requires an attorney and an administrator.</li>
      </ul>
    </Card>
    <Disclaimer/>
  </div>);
}
